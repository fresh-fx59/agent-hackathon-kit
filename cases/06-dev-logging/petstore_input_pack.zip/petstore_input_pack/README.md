# PetStore — стартовый пакет входных данных для команды

Набор иллюстрирует исходные артефакты для кейса **расширения GigaCode / core-агента** через skill, MCP/tool, rules и workflow. Задача — построить самообучающийся анализатор логов и предиктор аварий (AIOps + Sherlock) на примере микросервисного PetStore.

## Состав пакета

```
petstore_input_pack/
├── docs/           # архитектура, SDD, инцидент, требования, acceptance criteria
├── logs/           # логи сервисов, Kafka events, distributed traces, k8s events
├── tests/          # test cases, acceptance criteria, критерии оценки
└── repo/           # упрощённый мультирепо с 4 сервисами, k8s-манифестами и CI
```

## Целевой сценарий

Пользователь оформляет заказ в PetStore. Часть заказов падает **после успешной авторизации оплаты** из-за рассинхронизации между `order-service`, `payment-service` и `inventory-service`:

1. `payment-service` авторизует платёж → публикует `PaymentAuthorized` в Kafka.
2. `order-service` пытается синхронно вызвать `inventory-service.reserve()` с таймаутом 2s.
3. При частичной деградации `inventory-service` (латентность > 2s) вызов падает.
4. **БАГ:** `order-service` переводит заказ в терминальный статус `FAILED` вместо `PENDING_RETRY`, платёж уже списан → рассинхрон и жалоба клиента.

Инцидент воспроизводим в логах пакета (`correlation_id: c-8f3a2b91`).

## Что должна сдать команда

Переиспользуемый набор артефактов для core-агента:

- **Skill-пакет:** log parsing, incident classification, RCA reasoning, fix suggestion.
- **MCP/tools:** коннекторы к логам (ELK/файлы), стендам, репозиторию, k8s.
- **Rules:** сигнатуры ошибок, эвристики корреляции, триггеры алертов.
- **Workflow:** AIOps (near-real-time) и Sherlock (on-demand по жалобе QA).
- **Knowledge layer:** case memory + механизм обучения (переиспользование на следующем инциденте).
- **Интеграция:** API/MCP endpoint для подключения к GigaCode + документация.

## Как проверяем

- **Sherlock:** по `correlation_id` из жалобы QA команда без разработки находит root cause в `order-service::handleReservationTimeout` и предлагает фикс (`FAILED` → `PENDING_RETRY`).
- **AIOps:** система выявляет паттерн (`PaymentAuthorized` + `inventory timeout` + `order FAILED` в течение 10 сек) и предсказывает следующий инцидент.
- **Self-learning loop:** после разбора первого кейса система решает второй (эмуляция другой аварии — деградация `notification-service`) быстрее и без повторной ручной разметки.
- **Метрика успеха:** ≥50% дефектов на этом pet-project корректно диагностируются агентом без участия разработчика.

Подробнее — см. `docs/requirements.md` и `tests/acceptance_criteria.md`.
