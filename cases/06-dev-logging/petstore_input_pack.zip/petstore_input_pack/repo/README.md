# PetStore repo (упрощённый монорепо-фрагмент)

Минимальный, но компилируемый по смыслу набор сервисов. В коде **намеренно** заложен баг для кейса Sherlock.

## Сервисы

- `services/order-service` — Java 17 / Spring Boot 3. **Здесь баг** в `OrderCheckoutService`.
- `services/payment-service` — Java 17 / Spring Boot 3 (упрощённый).
- `services/inventory-service` — Python 3.11 / FastAPI (упрощённый).
- `services/notification-service` — Python 3.11 / FastAPI + Kafka consumer.

## Инфраструктура

- `k8s/` — Deployment/Service/HPA манифесты.
- `.github/workflows/ci.yaml` — CI (build/test/lint).

## Точка входа для агента

Root cause инцидента INC-2026-0142 находится в:
`services/order-service/src/main/java/com/petstore/order/svc/OrderCheckoutService.java`
метод `checkout()` → блок `catch (ReservationTimeoutException e) { ... }`.
