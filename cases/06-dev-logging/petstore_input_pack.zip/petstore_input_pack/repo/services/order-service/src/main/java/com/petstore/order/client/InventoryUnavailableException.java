package com.petstore.order.client;

public class InventoryUnavailableException extends Exception {
    public InventoryUnavailableException(String message) { super(message); }
}
