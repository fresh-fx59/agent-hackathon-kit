package com.petstore.order.client;

public class ReservationTimeoutException extends Exception {
    public ReservationTimeoutException(String message, Throwable cause) {
        super(message, cause);
    }
}
