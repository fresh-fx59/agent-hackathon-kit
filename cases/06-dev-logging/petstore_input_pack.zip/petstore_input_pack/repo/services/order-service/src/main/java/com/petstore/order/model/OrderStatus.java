package com.petstore.order.model;

public enum OrderStatus {
    CREATED,
    PAYMENT_PENDING,
    INVENTORY_PENDING,
    CONFIRMED,
    PENDING_RETRY,
    FAILED,
    SHIPPED
}
