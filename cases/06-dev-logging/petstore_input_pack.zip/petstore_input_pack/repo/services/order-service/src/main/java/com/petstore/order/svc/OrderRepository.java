package com.petstore.order.svc;

public interface OrderRepository {
    Order create(CheckoutRequest req);
    void save(Order order);
}
