package com.petstore.order.svc;

public record CheckoutResult(boolean ok, String orderId, String reason) {
    public static CheckoutResult ok(String id) { return new CheckoutResult(true, id, null); }
    public static CheckoutResult failed(String reason) { return new CheckoutResult(false, null, reason); }
}
