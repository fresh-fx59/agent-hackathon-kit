package com.petstore.order.client;

public class OutOfStockException extends Exception {
    public OutOfStockException(String message) { super(message); }
}
