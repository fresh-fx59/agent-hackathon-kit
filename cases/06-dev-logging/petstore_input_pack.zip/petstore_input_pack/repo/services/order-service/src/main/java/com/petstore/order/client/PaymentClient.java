package com.petstore.order.client;

import java.math.BigDecimal;

public interface PaymentClient {
    String authorize(String orderId, BigDecimal amount, String currency);
}
