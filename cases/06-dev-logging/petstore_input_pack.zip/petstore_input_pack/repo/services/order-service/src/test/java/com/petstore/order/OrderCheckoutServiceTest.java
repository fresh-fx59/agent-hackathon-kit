package com.petstore.order;

import com.petstore.order.model.OrderStatus;
import org.junit.jupiter.api.Test;

/**
 * Регрессионные тесты (заготовки), которые команда/агент должны предложить
 * при исправлении бага INC-2026-0142.
 *
 * Ожидаемое покрытие:
 *  1) при ReservationTimeoutException — order должен быть в PENDING_RETRY, retry запланирован;
 *  2) при InventoryUnavailableException — order в FAILED, release payment вызван;
 *  3) при OutOfStockException — order в FAILED, release payment вызван;
 *  4) при успехе — order в CONFIRMED, OrderCreated опубликован.
 */
public class OrderCheckoutServiceTest {

    @Test
    void reservation_timeout_should_result_in_pending_retry() {
        // TODO: implement — часть fix для INC-2026-0142.
        // assertEquals(OrderStatus.PENDING_RETRY, order.getStatus());
    }

    @Test
    void inventory_unavailable_should_result_in_failed_and_release_payment() {
        // TODO
    }
}
