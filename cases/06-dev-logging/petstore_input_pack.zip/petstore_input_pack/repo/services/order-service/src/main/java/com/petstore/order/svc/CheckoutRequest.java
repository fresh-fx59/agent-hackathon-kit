package com.petstore.order.svc;

import java.math.BigDecimal;

public record CheckoutRequest(String userId, String sku, int qty, BigDecimal amount, String currency) {}
