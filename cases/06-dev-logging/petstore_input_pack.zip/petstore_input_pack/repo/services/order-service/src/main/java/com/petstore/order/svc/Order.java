package com.petstore.order.svc;

import com.petstore.order.model.OrderStatus;

public class Order {
    private String id;
    private OrderStatus status;
    private String reservationId;
    // getters/setters (упрощены)
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public OrderStatus getStatus() { return status; }
    public void setStatus(OrderStatus s) { this.status = s; }
    public String getReservationId() { return reservationId; }
    public void setReservationId(String r) { this.reservationId = r; }
}
