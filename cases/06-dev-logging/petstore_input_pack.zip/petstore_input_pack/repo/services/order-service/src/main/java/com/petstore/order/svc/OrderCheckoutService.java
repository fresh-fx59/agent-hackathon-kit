package com.petstore.order.svc;

import com.petstore.order.client.*;
import com.petstore.order.kafka.OrderEventProducer;
import com.petstore.order.model.OrderStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Оркестратор checkout.
 *
 * ВНИМАНИЕ (для агента-Sherlock):
 *   В блоке catch(ReservationTimeoutException) заказ переводится сразу в FAILED,
 *   хотя платёж уже AUTHORIZED. Это нарушает SDD-инвариант И-1:
 *   при таймауте резервирования склада ожидаемый статус — PENDING_RETRY,
 *   а FAILED допустим только при явных InventoryUnavailableException/OutOfStockException.
 *
 *   Fix (ожидаемый):
 *     - для ReservationTimeoutException → PENDING_RETRY + планирование ретрая (5s, exp backoff, до 3 попыток);
 *     - для InventoryUnavailableException и OutOfStockException → FAILED + release payment.
 */
@Service
public class OrderCheckoutService {

    private static final Logger log = LoggerFactory.getLogger(OrderCheckoutService.class);

    private final PaymentClient paymentClient;
    private final InventoryClient inventoryClient;
    private final OrderRepository orderRepository;
    private final OrderEventProducer orderEventProducer;

    public OrderCheckoutService(PaymentClient paymentClient,
                                InventoryClient inventoryClient,
                                OrderRepository orderRepository,
                                OrderEventProducer orderEventProducer) {
        this.paymentClient = paymentClient;
        this.inventoryClient = inventoryClient;
        this.orderRepository = orderRepository;
        this.orderEventProducer = orderEventProducer;
    }

    public CheckoutResult checkout(CheckoutRequest req) {
        Order order = orderRepository.create(req);
        order.setStatus(OrderStatus.PAYMENT_PENDING);
        orderRepository.save(order);

        String authId;
        try {
            authId = paymentClient.authorize(order.getId(), req.amount(), req.currency());
        } catch (Exception e) {
            log.error("payment authorize failed", e);
            order.setStatus(OrderStatus.FAILED);
            orderRepository.save(order);
            orderEventProducer.publishOrderFailed(order, "payment_failed");
            return CheckoutResult.failed("payment_failed");
        }

        order.setStatus(OrderStatus.INVENTORY_PENDING);
        orderRepository.save(order);

        try {
            InventoryClient.ReservationResult res = inventoryClient.reserve(
                    order.getId(),
                    List.of(new InventoryClient.Item(req.sku(), req.qty())),
                    2000
            );
            order.setReservationId(res.reservationId());
            order.setStatus(OrderStatus.CONFIRMED);
            orderRepository.save(order);
            orderEventProducer.publishOrderCreated(order);
            return CheckoutResult.ok(order.getId());

        // -----------------------------------------------------------------
        // BUG (INC-2026-0142): timeout обрабатывается так же, как unavailable.
        // Здесь должно быть: PENDING_RETRY + scheduleRetry(...).
        // -----------------------------------------------------------------
        } catch (ReservationTimeoutException e) {
            log.error("reservation failed, marking order as FAILED", e);
            order.setStatus(OrderStatus.FAILED);                         // <-- НЕВЕРНО
            orderRepository.save(order);
            orderEventProducer.publishOrderFailed(order, "reservation_failed");
            return CheckoutResult.failed("reservation_failed");

        } catch (InventoryUnavailableException | OutOfStockException e) {
            log.error("inventory unavailable/out of stock", e);
            order.setStatus(OrderStatus.FAILED);
            orderRepository.save(order);
            // TODO: compensating action — release payment
            orderEventProducer.publishOrderFailed(order, "inventory_unavailable");
            return CheckoutResult.failed("inventory_unavailable");
        }
    }
}
