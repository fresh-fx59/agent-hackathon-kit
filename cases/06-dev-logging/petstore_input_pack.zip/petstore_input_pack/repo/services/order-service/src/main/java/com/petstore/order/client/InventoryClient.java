package com.petstore.order.client;

import org.springframework.stereotype.Component;

/**
 * Тонкий HTTP-клиент к inventory-service.
 * Различает 2 типа неуспеха:
 *  - ReservationTimeoutException  — сетевой read timeout (сервис жив, но медленный).
 *  - InventoryUnavailableException — явный HTTP 5xx / connect refuse.
 */
@Component
public class InventoryClient {

    public ReservationResult reserve(String orderId, java.util.List<Item> items, int timeoutMs)
            throws ReservationTimeoutException, InventoryUnavailableException, OutOfStockException {
        // ... реализация опущена — см. WebClient/RestTemplate обвязку.
        throw new UnsupportedOperationException("stub");
    }

    public record Item(String sku, int qty) {}
    public record ReservationResult(String reservationId) {}
}
