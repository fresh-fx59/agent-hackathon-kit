package com.petstore.order.kafka;

import com.petstore.order.svc.Order;

public interface OrderEventProducer {
    void publishOrderCreated(Order order);
    void publishOrderFailed(Order order, String reason);
}
