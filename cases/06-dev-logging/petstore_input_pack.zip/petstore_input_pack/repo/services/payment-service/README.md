# payment-service (stub)

Java / Spring Boot 3. Здесь приведены только сигнатуры для контекста.
