package com.petstore.payment;

import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.UUID;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    @PostMapping("/authorize")
    public AuthorizeResponse authorize(@RequestBody AuthorizeRequest req) {
        // ... psp call
        return new AuthorizeResponse("auth-" + UUID.randomUUID(), "AUTHORIZED");
    }

    public record AuthorizeRequest(String orderId, BigDecimal amount, String currency) {}
    public record AuthorizeResponse(String authId, String status) {}
}
