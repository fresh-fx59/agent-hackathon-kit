"""notification-service (упрощ.).

Kafka consumer: слушает orders.events.v1, шлёт email.
ВНИМАНИЕ: offset коммитится ДО подтверждения доставки — это
намеренный дефект для второго кейса self-learning loop.
"""
from __future__ import annotations

import logging
import os
import smtplib
from dataclasses import dataclass

log = logging.getLogger("notification-service")


@dataclass
class OrderEvent:
    type: str
    order_id: str
    correlation_id: str


def send_email(evt: OrderEvent) -> None:
    # simplified — реальный SMTP клиент с socket timeout
    with smtplib.SMTP(os.getenv("SMTP_HOST", "smtp.internal"), 587, timeout=5) as s:
        s.noop()
        # ... send


def handle_event(evt: OrderEvent, kafka_consumer) -> None:
    # BUG: commit до попытки доставки — нарушение at-least-once.
    kafka_consumer.commit()
    try:
        send_email(evt)
    except Exception as e:
        log.error("dropping message (no retry configured): %s", e)
        # message lost
