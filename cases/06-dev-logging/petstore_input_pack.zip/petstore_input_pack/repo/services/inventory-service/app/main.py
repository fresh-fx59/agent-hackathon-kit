"""inventory-service (упрощ.).

FastAPI /inventory/reserve. В pet-project искусственно моделируется
деградация: под нагрузкой обработка занимает 2-3s из-за row-lock ожидания.
"""
from __future__ import annotations

import asyncio
import os
import random
import uuid
from typing import List

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="inventory-service", version="0.9.1")

DEGRADED = os.getenv("DEGRADED", "false").lower() == "true"


class Item(BaseModel):
    sku: str
    qty: int


class ReserveRequest(BaseModel):
    order_id: str
    items: List[Item]
    ttl_seconds: int = 900


class ReserveResponse(BaseModel):
    reservation_id: str


@app.post("/inventory/reserve", response_model=ReserveResponse)
async def reserve(req: ReserveRequest) -> ReserveResponse:
    # Симуляция деградации: длительное ожидание row-lock под нагрузкой.
    if DEGRADED:
        await asyncio.sleep(random.uniform(2.2, 2.9))
    else:
        await asyncio.sleep(random.uniform(0.05, 0.35))
    return ReserveResponse(reservation_id=f"res-{uuid.uuid4()}")


@app.get("/healthz")
async def healthz() -> dict:
    return {"status": "ok", "degraded": DEGRADED}
