# PetStore — архитектура (упрощённая)

## Обзор

PetStore — интернет-магазин зоотоваров, построенный как набор микросервисов на Kubernetes. Транспорт: REST (внутренние вызовы) + Kafka (события). Хранилище: PostgreSQL per-service.

## Компоненты

| Сервис | Ответственность | Sync API | Async (Kafka) |
|---|---|---|---|
| `api-gateway` | публичный HTTP, маршрутизация, авторизация | — | — |
| `order-service` | жизненный цикл заказа, оркестрация checkout | `POST /orders`, `GET /orders/{id}` | consumes: `PaymentAuthorized`, `InventoryReserved`; produces: `OrderCreated`, `OrderFailed` |
| `payment-service` | авторизация и списание платежа | `POST /payments/authorize` | produces: `PaymentAuthorized`, `PaymentFailed` |
| `inventory-service` | резервирование и списание товара | `POST /inventory/reserve`, `POST /inventory/release` | produces: `InventoryReserved` |
| `notification-service` | email/push уведомления клиенту | — | consumes: `OrderCreated`, `OrderFailed` |
| `catalog-service` | каталог питомцев и товаров | `GET /catalog/*` | — |

## Диаграмма Checkout Flow (happy path)

```
Client → api-gateway → order-service
                          │
                          ├─(1) POST /payments/authorize ──→ payment-service
                          │      ← 200 { auth_id }
                          │
                          ├─(2) POST /inventory/reserve ──→ inventory-service
                          │      ← 200 { reservation_id }         (timeout 2s)
                          │
                          ├─(3) INSERT order (status=CONFIRMED)
                          │
                          └─(4) produce OrderCreated → Kafka → notification-service
```

## Точки отказа (known)

1. `inventory-service` под нагрузкой деградирует (p95 > 3s), нарушая SLA sync-вызова.
2. `order-service` не имеет ретрая на `inventory.reserve()` — сразу переводит в `FAILED`, хотя платёж уже авторизован.
3. Компенсирующая транзакция (release payment) выполняется асинхронно, окно рассинхрона до 30 сек.

## SLA / SLO (baseline)

- `order-service`: p95 checkout ≤ 1.5s, error rate ≤ 0.5%.
- `payment-service`: p95 ≤ 800ms.
- `inventory-service`: p95 ≤ 500ms (**фактически нарушается**).

## Стек

- Java 17 / Spring Boot 3 — `order-service`, `payment-service`.
- Python 3.11 / FastAPI — `inventory-service`, `notification-service`.
- Kafka 3.6, PostgreSQL 15, Redis 7.
- Kubernetes 1.29, Istio 1.22.
- Наблюдаемость: OpenTelemetry → Jaeger + Loki + Prometheus.
