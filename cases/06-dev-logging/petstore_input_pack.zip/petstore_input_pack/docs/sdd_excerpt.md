# SDD (System Design Document) — выдержка

Документ описывает контракты и инварианты, необходимые агенту для понимани�� корневой причины инцидентов. Полная версия — во внутреннем Confluence; здесь — минимально достаточный срез для RCA.

## 1. Order state machine

```
        ┌───────────┐    payment ok    ┌───────────┐   inventory ok   ┌───────────┐
CREATED─▶│ PAYMENT_  │──────────────────▶│INVENTORY_ │────────────────▶│ CONFIRMED │
        │ PENDING   │                   │ PENDING   │                   └─────┬─────┘
        └────┬──────┘                   └────┬──────┘                         │
             │payment fail                    │inventory fail                  │ ship
             ▼                                ▼                                ▼
        ┌───────────┐                   ┌───────────────┐                ┌──────────┐
        │  FAILED   │                   │ PENDING_RETRY │◀── ожидается   │ SHIPPED  │
        └───────────┘                   └───────┬───────┘   при timeout  └──────────┘
                                                │
                                                │ retry ok / manual
                                                ▼
                                          CONFIRMED / FAILED
```

**Инвариант И-1:** переход `INVENTORY_PENDING → FAILED` разрешён **только** если `payment.status != AUTHORIZED`. Иначе целевой статус — `PENDING_RETRY` (компенсирующая транзакция запускает release payment после N ретраев).

**Инвариант И-2:** если заказ в `FAILED`, а платёж в `AUTHORIZED` → рассинхрон, требуется алерт `INV-002`.

## 2. Контракты API

### `POST /inventory/reserve`

```json
{
  "order_id": "ord-<uuid>",
  "items": [{"sku": "SKU-...", "qty": 1}],
  "ttl_seconds": 900
}
```

Ответ: `200 { "reservation_id": "res-<uuid>" }` | `409 OUT_OF_STOCK` | `503 UNAVAILABLE`.

**Требование Т-1:** клиент (`order-service`) обязан различать `503` и network timeout: `503` → `FAILED`, timeout → `PENDING_RETRY`.

### `POST /payments/authorize`

```json
{ "order_id": "ord-<uuid>", "amount": "12.50", "currency": "EUR" }
```

Ответ: `200 { "auth_id": "auth-<uuid>", "status": "AUTHORIZED" }`.

## 3. Kafka topics

| Topic | Producer | Consumer | Key |
|---|---|---|---|
| `payments.events.v1` | payment-service | order-service, notification-service | `order_id` |
| `orders.events.v1` | order-service | notification-service, analytics | `order_id` |
| `inventory.events.v1` | inventory-service | order-service, analytics | `order_id` |

## 4. Correlation

Каждый входящий HTTP-запрос через `api-gateway` получает `X-Correlation-Id` (UUID). Он пробрасывается во все HTTP-заголовки, Kafka-хедер `correlation_id`, поле `correlation_id` в логах (JSON).

**Требование Т-2:** любой лог, связанный с обработкой заказа, обязан содержать `correlation_id` и `order_id`.

## 5. Известные исключения

- `ReservationTimeoutException` — сетевой таймаут вызова inventory. **Ожидаемая обработка:** перевод в `PENDING_RETRY`, планирование ретрая через 5s (экспоненциальный backoff, до 3 попыток).
- `InventoryUnavailableException` — HTTP 503. **Обработка:** `FAILED` + компенсирующий release payment.
- `OutOfStockException` — HTTP 409. **Обработка:** `FAILED` + release payment.
