# Тест-кейсы для проверки агента

Пакет содержит воспроизводимые кейсы. Агент запускается на входных данных из `logs/` и `repo/`, ожидаемые ответы указаны ниже.

---

## TC-01. Sherlock: Root cause по `correlation_id`

**Вход:** `correlation_id = c-8f3a2b91-4d7c-11ee-b962-0242ac120002`, доступ к `logs/*` и `repo/`.

**Ожидание:**
1. Агент собирает цепочку: `PaymentAuthorized` (OK) → `InventoryClient.reserve` (SocketTimeoutException, 2001ms) → order `INVENTORY_PENDING → FAILED`.
2. Помечает нарушение инварианта SDD **И-1** (`payment.status = AUTHORIZED` при переходе в `FAILED`).
3. Указывает файл + метод: `repo/services/order-service/.../OrderCheckoutService.java::handleReservationTimeout` (или эквивалент).
4. Предлагает исправление: при `ReservationTimeoutException` → `PENDING_RETRY`, планировать retry (5s, экспоненциально, до 3 попыток); только `InventoryUnavailableException` (503) и `OutOfStockException` (409) ведут в `FAILED`.
5. Указывает связанные тесты для регрессии.

**Метрика:** RCA-время ≤ 60s (p95); точность гипотезы (человек-эксперт) ≥ 80%.

---

## TC-02. AIOps: Обнаружение паттерна и предикция

**Вход:** stream `logs/order-service.log` + `logs/inventory-service.log` + `logs/kafka_events.jsonl` + `logs/metrics_snapshot.txt`.

**Ожидание:**
1. Rule/скор фиксирует паттерн: `p95(inventory-service) > 2s` + рост `order_status_transitions_total{to="FAILED"}` + `payment_authorized_without_order_confirmed_total > 0`.
2. Формирует раннее предупреждение с гипотезой: `dependency_degradation` в `inventory-service` (DB pool near-exhausted).
3. Задержка от первого события до алерта ≤ 30s.

**Метрика:** precision алерта ≥ 0.7 на смоделированном стриме (см. `tests/synthetic_stream.jsonl` — команда генерирует сама).

---

## TC-03. Self-learning loop: Второй инцидент (`notification-service`)

**Вход:** `logs/second_incident_notification.log`.

**Ожидание:**
1. Агент, обученный на TC-01, распознаёт похожий паттерн: `downstream timeout + fail-fast + no retry + at-least-once violation`.
2. Использует переиспользуемые правила из knowledge layer, а не заново обучается.
3. Root cause: `notification-service` коммитит offset до успешной отправки, нет retry.
4. Fix: настроить DLQ + ретрай, коммитить offset только после успешной доставки.

**Метрика:** время до RCA на TC-03 меньше, чем на TC-01, минимум на 30%.

---

## TC-04. Каскадная проверка на стенде

**Вход:** MCP tool `run_on_stand` с исправленным кодом (fix из TC-01).

**Ожидание:**
1. Агент запускает checkout под нагрузкой (эмуляция `inventory-service` slow).
2. Наблюдает переходы `INVENTORY_PENDING → PENDING_RETRY → CONFIRMED`.
3. Убеждается, что `payment_authorized_without_order_confirmed_total` не растёт.

---

## TC-05. Ложноположительный тест

**Вход:** happy-path заказ `ord-c88d1e2f...` (см. логи).

**Ожидание:**
- Агент не создаёт инцидент.
- Не помечает нарушение инвариантов.
